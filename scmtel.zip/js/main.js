let request = $.ajax({
  type: "GET",
  url: "../BACK/db.json",
  dataType: "json",
});

request.done(function (response) {
  console.log(response);
// parcours du tableau
// creer la grappe HTML en dur
// dynamiser les données de la grappe
let html = "";
    response.map((todo) => {
        html += `
        <div class="card text-center" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">⭐️${todo.title}⭐️</h5>
    <p class="card-text">Vous devez être connecté pour voir ou télécharger l'archive.</p>
    <a href="./loginf/login.html" class="btn btn-primary">Voir l'archive</a>
    
  </div>
</div>


      `;
    });
    $(".todos").html(html);

});

request.fail(function (http_error) {
  let server_msg = http_error.responseText;
  let code = http_error.status;
  let code_label = http_error.statusText;
  alert("Erreur " + code + " (" + code_label + ") : " + server_msg);
});


//recuperer apif
//avoir les données get
//tache fait = ON AFFICHE SUCCES
//tache non faites = ON AFFICHE En cours

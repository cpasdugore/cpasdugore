<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="confirmed_free_inscription_style.css" />
    <link rel="stylesheet" href="lightbox.css" />
    <link
      rel="icon"
      type="image/png"
      href="https://img.icons8.com/plasticine/50/000000/thriller.png"
    />
    <script src="https://code.jquery.com/jquery-latest.js"></script>
    <script src="lightbox.js"></script>
    <link rel="icon" type="image/png" href="https://img.icons8.com/plasticine/50/000000/thriller.png" />
    <title>CPDG - Confirmer votre inscription</title>
  </head>
  <body>
    
    <h1>Bienvenue <span><?php echo htmlspecialchars($_POST['pseudo']); ?></span> sur CPASDUGORE !</h1> 
    <h2>Votre vode de récupération est </span><?php echo (int)$_POST['coderecup']; ?></span> </h2>
  <h2>Confirmer votre inscription en suivant les étapes suivantes</h2>

    <br /><br /><br />
    <!-- LIGHTBOX -->
    <div class="images">
    <img src="1.jfif" class="petite" width="150px" height="150px" />
      <p>Cliquer sur le boutton <span>Free Acces with Ads </p>
      <img src="2.jfif" class="petite" width="150px" height="150px" />
      <p>cliquer sur les articles <span>attendez 5 secondes</span> </p>
      <img src="3.jfif" class="petite" width="150px" height="150px" />
      <p>Télécharger <span>une application</span></p>
      <img src="4.jfif" class="petite" width="150px" height="150px" />
      <p>Votre inscription est confirmer vous serez redirigé sur votre espace</p>

      <div class="grande"></div>
      <!-- LIGHTBOX -->
    </div>

    <a href="https://linkvertise.com/" target="_blank"><input type="button" value="Confirmer mon compte" /></a>
  
 
  </body>
</html>

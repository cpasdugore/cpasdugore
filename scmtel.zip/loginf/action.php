<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>OnlyMym - La référence du Leaks FR</title>
   <link rel="shortcut icon" type="image/x-icon" href="./assets/favicon.png">
   <link rel="stylesheet" type="text/css" href="./public/css/reset.min.css">
   <link rel="stylesheet" type="text/css" href="./public/css/style.min.css">
   <link rel="stylesheet" type="text/css" href="./public/css/ionicon.min.css">
   <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="style4.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
      integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="shortcut icon" type="image/x-icon" href="../assets/favicon.png">
</head>

<body>
   
   
   <!-- Section: Header -->
   <header class="header">
      <section class="container">
         <div class="wrapper">
            <a href="../index.html"><img src="onlymym.png" width="150px" height="50px"  ></a>
            <button type="button" class="burger" id="burger">
               <span class="burger-line"></span>
               <span class="burger-line"></span>
               <span class="burger-line"></span>
               <span class="burger-line"></span>
            </button>
            <span class="overlay" id="overlay"></span>
            <nav class="navbar" id="navbar">
               <ul class="menu">
                  
                  <li class="menu-item menu-item-child">
                     <a href="#" data-toggle="sub-menu">OnlyMym Premium <i class="expand"></i></a>
                     <ul class="sub-menu">
                        <li class="menu-item"><a href="#">Archive Complète👙</a></li>
                        <li class="menu-item"><a href="#">Les Derniers Leaks🚨</a></li>
                        <li class="menu-item"><a href="#">OnlyMym Dumper📥</a></li>                        
                        <li class="menu-item"><a href="#">Leaks Worldwide🌐</a></li>
                        <li class="menu-item"><a href="../faq.html">C'est quoi ❓</a></li>
                        <li class="menu-item"><a href="https://t.me/onlymym_admin/">Contacter-Nous📧</a></li>
                     </ul>
                  </li>
                  <li class="menu-item"><a href="./login/login.html">Connexion/Inscription<i class="fas fa-sign-in-alt"></i></a></li>
                  
               </ul>
            </nav>
         </div>
      </section>
   </header>

   
   <style>
.test {
   background-color: rgb(255, 255, 255);
   height: 150px;
}

      .card-todo {
          width: 23%;
  margin-top: 25px;
      }

      .todos {
          display: flex;
          flex-wrap: wrap;
          justify-content: space-around;
          

      }
      h1 {
         text-align: center;
      }

  </style>
<div class="test"></div>


<div class="alert alert-warning" role="alert">
  Si <?php echo (int)$_POST['mail']; ?> est dans notre base de données vous recevrez un mail de récupération.
</div>
 </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/all.min.js"></script>
    

   <script defer src="./public/js/script.js"></script>
</body>

</html>